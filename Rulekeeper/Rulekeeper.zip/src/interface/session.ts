export interface Session {
  __language_code?: string;
}
